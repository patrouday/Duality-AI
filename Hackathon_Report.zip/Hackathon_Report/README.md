#  Space Safety Equipment Detection using YOLOv5  

This project implements an **AI-powered detection system** for identifying critical safety equipment such as Helmet, Oxygen Kit, Fire Extinguisher, Tool Kit, First Aid Kit, Gloves, and Communication Device using the **YOLOv5 deep learning framework**.  

---

##  Project Structure  
```
yolov5/
│── data/                # Dataset and YAML config files
│── runs/                # Training outputs (weights, results, etc.)
│── detect.py            # Script for inference
│── train.py             # Script for training
│── requirements.txt     # Python dependencies
│── README.md            # Project documentation
```

---

##  Environment Setup  

### 1. Clone the Repository  
```bash
git clone https://github.com/ultralytics/yolov5.git
cd yolov5
```

### 2. Create Conda Environment  
```bash
conda create -n torch310 python=3.10 -y
conda activate torch310
```

### 3. Install Dependencies  
```bash
pip install -r requirements.txt
```

### 4. Install PyTorch with CUDA (GPU)  
(Adjust CUDA version based on your system)  
```bash
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121
```

---

##  Training the Model  

### 1. Dataset  
Ensure dataset is structured as:  
```
datasets/space_safety/
│── images/
│    ├── train/
│    ├── val/
│── labels/
     ├── train/
     ├── val/
```

### 2. Train Command  
```bash
python train.py --img 640 --batch 16 --epochs 80 --data data/space_safety.yaml --weights yolov5s.pt --device 0 --name space_safety
```

- **img** = input image size (640x640)  
- **batch** = batch size (adjust if GPU memory low)  
- **epochs** = number of training epochs  
- **data** = dataset YAML file  
- **weights** = pretrained weights (yolov5s.pt)  
- **device** = GPU (0) or CPU (cpu)  

---

##  Testing / Inference  

### Run detection on images or video:  
```bash
python detect.py --weights runs/train/space_safety/weights/best.pt --img 640 --conf 0.25 --source data/space_safety/images/val
```

### Run on a video file:  
```bash
python detect.py --weights runs/train/space_safety/weights/best.pt --img 640 --conf 0.25 --source "C:/Users/mukhi/Videos/demo.mp4"
```

### Run on webcam:  
```bash
python detect.py --weights runs/train/space_safety/weights/best.pt --img 640 --conf 0.25 --source 0
```

---

##  Reproducing Results  

- **80 Epoch Model**: mAP@50 = **0.756**, mAP@50-95 = **0.552**  
- **Extended 200 Epochs**: Best performance at **epoch 156**, mAP@50 = **~0.86**  
- Results are saved in:  
```
runs/train/space_safety/results.png
runs/train/space_safety/weights/best.pt
```

---

##  Expected Outputs  

- Bounding boxes drawn around detected objects.  
- Class labels and confidence scores displayed on images/video.  
- Evaluation metrics include **Precision, Recall, mAP50, mAP50-95**.  

Example:  
```
Class     Precision    Recall   mAP@50   mAP@50-95
Helmet       0.925       0.728     0.794      0.623
Oxygen Kit   0.902       0.692     0.773      0.567
Fire Ext.    0.892       0.655     0.743      0.567
...
```

---

##  Notes  

- Training with more epochs (~200) improved accuracy significantly.  
- GPU recommended (minimum 4GB VRAM). Training on CPU is very slow.  
- You can resume training if interrupted:  
```bash
python train.py --resume runs/train/space_safety/weights/last.pt
```
